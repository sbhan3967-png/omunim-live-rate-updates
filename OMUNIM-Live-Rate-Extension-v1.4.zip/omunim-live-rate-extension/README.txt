OMUNIM Live MCX Rate Calculator — v1.4
========================================

v1.4 me naya: premium ke baad wala rate
----------------------------------------
- Board (24K/22K/20K/18K/14K/Silver) aur item ka rate ab MCX + premium
  wala dikhta hai — premium popup se set hota hai (gold Rs/10g,
  silver Rs/kg). Premium 0 ho to sab kuch pehle jaisa hi rahega.
- Fallback mode me ghadi turant bhar jati hai (render ke saath hi),
  aur "Purana rate" warning sirf tabhi aati hai jab top-bar fallback
  nahi chal raha.

v1.3 me naya: minimal panel + fallback fix
-------------------------------------------
- Panel ab minimal hai. Koi item khula nahi ho to sirf rate board:
  24K, 22K (92%), 20K (85%), 18K (76%), 14K (60%) — MCX gold rate se —
  aur Silver rate. Koi extra word nahi.
- Item khula ho to sirf: Item, MCX rate, bada FINAL PRICE, aur ek line
  OMUNIM price + Fark. Breakdown (metal, making, hallmark, GST...),
  note aur premium inputs panel se hata diye — premium popup se set hota hai.
- Fallback fix (v1.2 live test me pakda gaya bug): fetch fail hone par
  fetchedAt aage nahi badhta, isliye 90 second purana rate hote hi
  OMUNIM top bar ka MCX rate use hota hai. Ghadi bhi ab sirf time dikhati hai.

v1.2 me naya: auto-refresh fix
------------------------------
- Gold aur Silver ab alag-alag fetch hote hain — ek page slow/fail ho to
  bhi dusre ka rate update hota hai, aur price freeze nahi hota.
- Agar mcxlive.org se rate 90 second se zyada purana ho jaye to panel
  OMUNIM ke upar wale bar ka MCX rate use kar leta hai ("MCX Gold:..."
  jo OMUNIM server se aata hai) — "OMUNIM top bar se" likh kar.
- Panel me ab har second tick karne wali ghadi hai: "Updated HH:MM:SS"
  aur "Next refresh in Ns" — refresh ho raha hai ya nahi, dikhai dega.
- Rate lene me error aaye to uska kaaran panel aur popup me likha aayega.
- Background alarm ab har message par bhi check hota hai (self-healing).

v1.1 me naya: GitHub auto-update check
---------------------------------------
- Extension har ghante GitHub channel
  sbhan3967-png/omunim-live-rate-updates ka version.json check karta hai
  (popup kholne par bhi check hota hai).
- Naya version mile to popup aur OMUNIM panel me "Naya version available"
  banner aata hai, download link ke saath.
- SAAF SAAF: Chrome Load-unpacked extension ko khud se update NAHI karta
  (sirf Chrome Web Store wale apne aap update hote hain). Isliye update
  2-step ka hai: (1) banner se naya ZIP download karo, (2) usi folder me
  extract karo aur chrome://extensions me extension ka Reload dabao.
  Premium settings chrome.storage me rehti hain, update se delete nahi hoti.
- Channel: https://github.com/sbhan3967-png/omunim-live-rate-updates
  version.json: https://raw.githubusercontent.com/sbhan3967-png/omunim-live-rate-updates/main/version.json

Kya karta hai
------------
OMUNIM ke OwnerHome page par jab koi item detail khulta hai (jaise DLR16),
ye extension uska FINAL PRICE live MCX rate se calculate karke ek floating
panel me dikhata hai.

- Rate source: https://mcxlive.org/ (gold page + silver page) — wahi source
  jo Weighing Scale app v1.48 me use hota hai (window.FD_FEED JSON).
- Refresh: har 1 minute me apne aap (aapke rule ke hisaab se).
- OMUNIM ka Metal Amount use NAHI hota — woh purane rate par based hota
  hai. Fresh metal value = Fine Weight x (MCX + premium).
- Premium: Gold (Rs/10g) aur Silver (Rs/1kg) — popup ya panel se kabhi bhi
  add kar sakte hain. 0 rakha to raw MCX rate use hoga.
- Baaki charges page se liye jate hain: dia Amt, Making, Hallmark, Other.
  Making GM / % / per-piece — jaisa page par likha ho, waisa calculate
  hota hai. GST page wale % se (aam taur par 3%).
- Sirf is page par kaam karta hai:
  https://release.omunim.in/2/omHomePage.php?divPanel=OwnerHome
  (Detail AJAX panel se khulta hai, URL nahi badalta — extension DOM
  change ko observe karta hai.)

DLR16 par verified hisaab (22 Nov 2026, MCX Gold 1,21,949 /10g)
---------------------------------------------------------------
Fine Wt 2.7072 g (Net 4.512 g x 60%) x 12,194.90/g = Metal 33,014.03
+ dia 43,600.00 + Making 1,200 x 2.7072 = 3,248.64
+ Hallmark 200.00 + Other 1,000.00 = Subtotal 81,062.67
+ GST 3% 2,431.88 = FINAL 83,494.55
(OMUNIM price us waqt 85,516.43 tha — fark -2,021.88, kyunki MCX gir gaya tha.)

Install kaise karein (Chrome / Brave)
--------------------------------------
1. Is ZIP ko extract karein — ek folder milega "omunim-live-rate-extension".
2. Chrome me chrome://extensions kholein.
3. Upar right "Developer mode" ON karein.
4. "Load unpacked" dabayein aur wahi folder select karein.
5. OMUNIM OwnerHome page kholein, koi item kholein — right-bottom corner
   me gold panel dikhega: live rate, breakdown, aur FINAL PRICE.
6. Premium: panel ke neeche ya extension icon (toolbar) wale popup se
   Gold/Silver premium daal kar Save dabayein.

Dhyaan dene wali baatein
------------------------
- MCX market band ho (raat / weekend / holiday) to aakhri trade ka rate
  dikhega, uska time saaf likha hoga — use live samajh kar galti na karein.
- Rate na mile to purana rate "stale" likh kar dikhega; galat rate kabhi
  nahi dikhaya jata. Backup ke taur par OMUNIM ke top bar ka MCX rate
  use hota hai (wahan bhi "MCX Gold:121949" likha hota hai).
- Extension kuch bhi save / bill / edit nahi karta — sirf price dikhata hai.
- Agar OMUNIM page ka layout badal jaye to panel "detail nahi mila" dikha
  sakta hai — us waqt mujhe batayein, parser update kar dunga.

Files
-----
manifest.json, background.js (MCX fetch, 1-min alarm), omunim-parse.js
(parsing + calculation, shared), content.js (floating panel), content
panel styling content.js ke andar hai, popup.html / popup.js (settings),
test/test_calc.js (Node test — DLR16 ke verified numbers par).
