/* Popup: live MCX rates + premium settings for the OMUNIM extension. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };

  function showRates() {
    chrome.runtime.sendMessage({ type: "GET_MCX" }, function (res) {
      if (!res || !res.mcx) {
        $("gold").textContent = "nahi mila";
        $("silver").textContent = "nahi mila";
        $("fetched").textContent = res && res.error ? String(res.error) : "—";
        return;
      }
      var g = res.mcx.gold, s = res.mcx.silver;
      $("gold").textContent = "\u20b9" + formatINR(g.last, 0) + " /10g";
      $("silver").textContent = "\u20b9" + formatINR(s.last, 0) + " /kg";
      $("fetched").textContent = res.mcx.fetchedAt ? new Date(res.mcx.fetchedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—";
      chrome.storage.local.get(["mcxError"], function (r2) {
        if (r2.mcxError) $("status").textContent = "Rate lene me error: " + r2.mcxError;
      });
    });
  }

  function showUpdate() {
    chrome.storage.local.get(["update"], function (res) {
      var u = res.update;
      var el = $("update");
      if (u && u.available) {
        el.style.display = "block";
        el.innerHTML = "Naya version <b>" + u.latest + "</b> available hai" +
          (u.notes ? " — " + u.notes : "") + ". ";
        if (u.url) {
          var a = document.createElement("a");
          a.href = u.url; a.textContent = "ZIP download karo";
          a.target = "_blank";
          el.appendChild(a);
          el.appendChild(document.createTextNode(" — phir folder me extract karke chrome://extensions me Reload dabao."));
        }
      } else {
        el.style.display = "none";
      }
    });
  }

  chrome.storage.local.get(["goldPremium", "silverPremium", "liveRateEnabled"], function (res) {
    $("premg").value = parseFloat(res.goldPremium) || 0;
    $("prems").value = parseFloat(res.silverPremium) || 0;
    $("enabled").checked = res.liveRateEnabled !== false;
  });
  showRates();
  showUpdate();
  chrome.runtime.sendMessage({ type: "CHECK_UPDATE" }, function () { showUpdate(); });

  $("save").addEventListener("click", function () {
    var g = Math.max(0, parseFloat($("premg").value) || 0);
    var s = Math.max(0, parseFloat($("prems").value) || 0);
    chrome.storage.local.set({ goldPremium: g, silverPremium: s, liveRateEnabled: $("enabled").checked }, function () {
      $("status").textContent = "Save ho gaya — OMUNIM page par final price turant update ho jayega.";
    });
  });
  $("enabled").addEventListener("change", function () {
    chrome.storage.local.set({ liveRateEnabled: $("enabled").checked });
  });
  $("refresh").addEventListener("click", function () {
    $("status").textContent = "Rate refresh ho raha hai…";
    chrome.runtime.sendMessage({ type: "REFRESH_MCX" }, function () {
      showRates();
      $("status").textContent = "Rate refresh ho gaya.";
    });
    chrome.runtime.sendMessage({ type: "CHECK_UPDATE" }, function () { showUpdate(); });
  });
})();
