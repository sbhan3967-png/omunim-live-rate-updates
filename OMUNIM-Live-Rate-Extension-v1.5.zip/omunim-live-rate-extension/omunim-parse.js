/* OMUNIM Live MCX Rate Calculator — pure parsing / calculation helpers.
   No chrome.* APIs in this file, so background.js, content.js, popup.js
   and the Node test can all share it.

   VERIFIED FACTS (browser verification, 22 Nov 2026, DLR16 / barcode 1016):
   - Detail opens inside OwnerHome by AJAX panel swap; URL stays
     https://release.omunim.in/2/omHomePage.php?divPanel=OwnerHome
   - Every field is a table row: label | ":" | value (plain text, no
     reliable ids/classes) — so parsing anchors on exact label text.
   - Metal Amount 34,977.02 = fine 2.7072 g x pure Rs 12,920/g
     (i.e. Rs 1,29,200/10 g at stock-entry time). Net 4.512 g x Final
     Purity 60% = 2.7072 g. Making 1,200 x 2.7072 = 3,248.64.
   - GST = 3% of Total Amount. dia Amt 43,600 = stone-table AMT.
   - Top bar itself shows "MCX Gold:121949" / "MCX Silver:148900".

   MCX SOURCE: https://mcxlive.org/gold/ and /silver/ — the live quote
   is embedded as window.FD_FEED JSON (last = per 10 g gold, per 1 kg
   silver). Same source + parser as the Weighing Scale app v1.48.
   Old "Last Trade" table parser is kept as fallback.
*/

function parseNum(s) {
  if (s === null || s === undefined) return null;
  var n = parseFloat(String(s).replace(/[,\u20b9\s]/g, ""));
  return isNaN(n) ? null : n;
}

function formatINR(n, decimals) {
  if (decimals === undefined) decimals = 2;
  if (n === null || n === undefined || isNaN(n)) return "-";
  try {
    return Number(n).toLocaleString("en-IN", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  } catch (e) {
    return Number(n).toFixed(decimals);
  }
}

/* ---- MCX page parsing (mcxlive.org) ---- */

function parseFdFeed(html, metal) {
  if (!html) return null;
  try {
    var m = html.match(/window\.FD_FEED=(\{.*?\});window\.FD_DATA/s);
    if (!m) return null;
    var d = JSON.parse(m[1]);
    var last = parseFloat(d.last);
    if (!(last > 0)) return null;
    var close = parseFloat(d.close) || 0;
    var change = d.c_value !== undefined ? parseFloat(d.c_value) : (close ? last - close : 0);
    var pct = d.c_percent !== undefined ? parseFloat(d.c_percent) : (close ? (change / close) * 100 : 0);
    var out = {
      metal: metal,
      last: last,
      change: change,
      change_pct: pct,
      contract: String(d.expiry || d.name || ""),
      as_on: String(d.c_datetime || ""),
      last_trade: String(d.t_datetime || ""),
      status: String(d.status || ""),
      unit: metal === "GOLD" ? "10 g" : "1 kg"
    };
    ["high", "low", "open"].forEach(function (k) {
      if (d[k] !== undefined) out[k] = parseFloat(d[k]);
    });
    return out;
  } catch (e) {
    return null;
  }
}

function parseMcxPage(html, metal) {
  if (!html) return null;
  var fd = parseFdFeed(html, metal);
  if (fd) return fd;
  // Fallback: old server-rendered "Last Trade" table layout.
  try {
    var lastM = html.match(
      /Last Trade<\/td>[\s\S]*?<td class="main-change[^"]*">.*?([\d,]+)<\/td>\s*<td class="main-change[^"]*">\s*([+-]?[\d,]+)<\/td>\s*<td class="main-change[^"]*">\s*([+-]?[\d.]+%)<\/td>/);
    if (!lastM) return null;
    var contractM = html.match(/<h2 class="main-head">MCX (?:Gold|Silver)\s+([^<]+)<\/h2>/);
    var asOnM = html.match(/As on\s+([^<]+?),\s*India Time/);
    return {
      metal: metal,
      last: parseNum(lastM[1]),
      change: parseNum(lastM[2]),
      change_pct: parseFloat(String(lastM[3]).replace("%", "")),
      contract: contractM ? contractM[1].trim() : "",
      as_on: asOnM ? asOnM[1].trim() : "",
      last_trade: "",
      status: "",
      unit: metal === "GOLD" ? "10 g" : "1 kg"
    };
  } catch (e) {
    return null;
  }
}

/* ---- OMUNIM panel parsing (by exact label text) ---- */

function _labelNum(text, labelPattern) {
  var re = new RegExp(labelPattern + "\\s*:\\s*([\\d,]+\\.?\\d*)", "i");
  var m = text.match(re);
  return m ? parseNum(m[1]) : null;
}

function parsePanelText(text) {
  if (!text) return null;
  // Normalise: non-breaking spaces, "Rs." artefacts, tabs.
  var t = String(text).replace(/\u00a0/g, " ");
  if (!/ITEM DETAILS PANEL/i.test(t) && !/Product Code\s*:/i.test(t)) return null;

  var p = {};
  var m;
  m = t.match(/Product Code\s*:\s*([A-Za-z0-9\-_]+)/i);
  p.productCode = m ? m[1] : null;
  m = t.match(/Barcode No\s*:\s*([A-Za-z0-9\-]+)/i);
  p.barcode = m ? m[1] : null;
  m = t.match(/Metal\s*:\s*(Gold|Silver|Platinum)/i);
  p.metal = m ? m[1] : null;
  // Product name is the heading (e.g. "Dlring") — best effort only.
  m = t.match(/ITEM DETAILS PANEL[\s\S]{0,400}?\n\s*([A-Za-z][A-Za-z ]{2,30})\n/i);
  p.productName = m ? m[1].trim() : null;

  p.qty = _labelNum(t, "Item Quantity");
  p.grossWt = _labelNum(t, "Gross Weight");
  p.lessWt = _labelNum(t, "Less Weight");
  p.netWt = _labelNum(t, "Net Weight");
  p.totalWt = _labelNum(t, "Total Weight");
  p.purity = _labelNum(t, "Purity");
  p.wastage = _labelNum(t, "Item Wastage");
  p.finalPurity = _labelNum(t, "Final Purity");
  p.fineWt = _labelNum(t, "Fine Weight");
  p.finalFineWt = _labelNum(t, "Final Fine Weight");

  m = t.match(/Other Charges\s*:\s*([\d,]+)\s*Fixed/i);
  p.otherChargesFixed = m ? parseNum(m[1]) : null;

  p.metalAmtOld = _labelNum(t, "Metal Amount");
  p.diaAmt = _labelNum(t, "dia Amt");
  m = t.match(/Making Charges\s*(?:\(([^)]*)\))?\s*:\s*([\d,]+\.\d{2})/i);
  p.makingAmtOld = m ? parseNum(m[2]) : null;
  p.makingBracket = m && m[1] ? m[1].trim() : null;
  p.hallmarkAmt = _labelNum(t, "Hallmark Charges");
  // Right-column Other Charges has decimals (1,000.00); the middle
  // "1000 Fixed" has none, so the decimal form picks the right one.
  var others = [];
  var reOther = /Other Charges\s*:\s*([\d,]+\.\d{2})/gi;
  var om;
  while ((om = reOther.exec(t)) !== null) others.push(parseNum(om[1]));
  p.otherAmt = others.length ? others[0] : null;
  p.totalAmtOld = _labelNum(t, "Total Amount");
  p.gstAmtOld = _labelNum(t, "GST Amount");
  m = t.match(/Price\s*:\s*\u20b9?\s*([\d,]+\.\d{2})/i);
  p.priceOld = m ? parseNum(m[1]) : null;
  m = t.match(/Final Price\s*\u20b9?\s*([\d,]+\.\d{2})/i);
  p.finalPriceOld = m ? parseNum(m[1]) : null;

  // OMUNIM's own top bar also shows MCX — fallback if mcxlive fetch fails.
  m = t.match(/MCX Gold\s*:\s*([\d,]+)/i);
  p.topMcxGold = m ? parseNum(m[1]) : null;
  m = t.match(/MCX Silver\s*:\s*([\d,]+)/i);
  p.topMcxSilver = m ? parseNum(m[1]) : null;

  // Nothing usable without weights.
  if (p.netWt === null && p.fineWt === null && p.totalWt === null) return null;
  return p;
}

/* ---- Price calculation ----
   The OMUNIM Metal Amount is NEVER used. Fresh metal value is:
     Gold:   fineWt(g) x (MCX gold + gold premium) / 10
     Silver: fineWt(g) / 1000 x (MCX silver + silver premium)
   Fine weight is taken unrounded where possible: Net x Final Purity%,
   because OMUNIM itself used 2.7072 g (not the displayed 2.707 g).
   Making: % -> % of new metal; GM -> rate x the weight it was charged
   on (found by matching displayed making / rate to a known weight,
   else fine weight); PP/PC -> rate x qty; Fixed / no bracket -> as shown.
   GST rate is read from the page (GST / Total, normally 3%), else 3%.
*/
function computePrice(p, rates, premiums) {
  premiums = premiums || {};
  var isSilver = !!(p.metal && /silver/i.test(p.metal));
  var mcxRaw = isSilver ? (rates && rates.silver && rates.silver.last) : (rates && rates.gold && rates.gold.last);
  var premium = isSilver ? (parseFloat(premiums.silver) || 0) : (parseFloat(premiums.gold) || 0);
  var mcx = (mcxRaw === null || mcxRaw === undefined) ? null : mcxRaw + premium;
  var ratePerGram = null;
  if (mcx !== null) ratePerGram = isSilver ? mcx / 1000 : mcx / 10;

  var fineExact = null;
  if (p.netWt !== null && p.finalPurity !== null) fineExact = (p.netWt * p.finalPurity) / 100;
  else if (p.netWt !== null && p.purity !== null) fineExact = (p.netWt * p.purity) / 100;
  else if (p.finalFineWt !== null) fineExact = p.finalFineWt;
  else if (p.fineWt !== null) fineExact = p.fineWt;

  var fineShown = p.finalFineWt !== null ? p.finalFineWt : (p.fineWt !== null ? p.fineWt : fineExact);
  var newMetal = (ratePerGram !== null && fineExact !== null) ? fineExact * ratePerGram : null;

  // Making charges.
  var making = { amount: p.makingAmtOld || 0, basis: "as shown", rate: null, unit: null };
  if (p.makingBracket) {
    var b = p.makingBracket;
    var bm = b.match(/([\d,]+\.?\d*)\s*(%|GM|G|PP|PC|PER PIECE|PIECE|FIXED)?/i);
    if (bm) {
      var rate = parseNum(bm[1]);
      var unit = (bm[2] || "").toUpperCase();
      making.rate = rate;
      making.unit = unit;
      if (unit === "%") {
        making.amount = newMetal !== null ? (newMetal * rate) / 100 : (p.makingAmtOld || 0);
        making.basis = rate + "% of new metal amount";
      } else if (unit === "PP" || unit === "PC" || unit === "PER PIECE" || unit === "PIECE") {
        var qty = p.qty || 1;
        making.amount = rate * qty;
        making.basis = "Rs " + formatINR(rate, 0) + " x " + qty + " pc";
      } else if (unit === "GM" || unit === "G") {
        // Which weight was it charged on? Match displayed / rate.
        var base = fineExact, baseName = "fine wt";
        if (rate > 0 && p.makingAmtOld) {
          var implied = p.makingAmtOld / rate;
          var cands = [
            ["fine wt", fineExact], ["net wt", p.netWt],
            ["total wt", p.totalWt], ["gross wt", p.grossWt]
          ];
          for (var i = 0; i < cands.length; i++) {
            var cw = cands[i][1];
            if (cw && Math.abs(implied - cw) / cw < 0.005) { base = cw; baseName = cands[i][0]; break; }
          }
        }
        making.amount = rate * (base || 0);
        making.basis = "Rs " + formatINR(rate, 0) + "/g x " + (base !== null ? base.toFixed(3) : "-") + " g (" + baseName + ")";
      } else {
        making.amount = p.makingAmtOld || 0;
        making.basis = "as shown (" + b + ")";
      }
    }
  }

  var dia = p.diaAmt || 0;
  var hallmark = p.hallmarkAmt || 0;
  var other = p.otherAmt !== null ? p.otherAmt : (p.otherChargesFixed || 0);
  var subtotal = newMetal !== null ? newMetal + dia + making.amount + hallmark + other : null;

  var gstRate = 0.03;
  if (p.gstAmtOld && p.totalAmtOld) gstRate = p.gstAmtOld / p.totalAmtOld;
  var gst = subtotal !== null ? subtotal * gstRate : null;
  var finalPrice = subtotal !== null ? subtotal + gst : null;
  var oldFinal = p.finalPriceOld !== null ? p.finalPriceOld : (p.priceOld !== null ? p.priceOld : null);
  var diff = (finalPrice !== null && oldFinal !== null) ? finalPrice - oldFinal : null;

  return {
    isSilver: isSilver,
    mcxRaw: mcxRaw,
    premium: premium,
    mcxWithPremium: mcx,
    ratePerGram: ratePerGram,
    fineExact: fineExact,
    fineShown: fineShown,
    newMetal: newMetal,
    dia: dia,
    making: making,
    hallmark: hallmark,
    other: other,
    subtotal: subtotal,
    gstRate: gstRate,
    gst: gst,
    finalPrice: finalPrice,
    oldFinal: oldFinal,
    oldMetal: p.metalAmtOld,
    diff: diff
  };
}

/* ---- Rate picking (v1.2) ----
   Which rate should the panel use right now?
   - Background mcxlive rate fresh (< 90 s old): use it.
   - Background rate stale/missing BUT OMUNIM's own top bar shows an
     MCX rate ("MCX Gold:124908" — OMUNIM's server rate, always fresh
     while OMUNIM is open): use the top-bar rate, labelled fallback.
     A fallback rate object is always re-read from the page, never
     treated as fresh, so it keeps tracking the top bar.
   - Otherwise: keep whatever rate object we have (possibly null). */
function pickRate(mcx, parsed, nowMs) {
  nowMs = nowMs || Date.now();
  var age = (mcx && mcx.fetchedAt) ? nowMs - new Date(mcx.fetchedAt).getTime() : Infinity;
  if (mcx && mcx.source === "omunim-topbar") age = Infinity; // re-read every time
  // v1.3: a stale merge (fetch failed, last-good values reused) is stale
  // even if its fetchedAt was just stamped — judge by the fresh flags too.
  if (mcx && (mcx.goldFresh === false || mcx.silverFresh === false)) age = Infinity;
  if (mcx && age <= 90 * 1000) return { mcx: mcx, fallback: false };
  if (parsed && parsed.topMcxGold) {
    var silverLast = parsed.topMcxSilver || (mcx && mcx.silver ? mcx.silver.last : 0);
    return {
      mcx: {
        gold: { last: parsed.topMcxGold, status: "", last_trade: "" },
        silver: { last: silverLast, status: "", last_trade: "" },
        fetchedAt: new Date(nowMs).toISOString(),
        source: "omunim-topbar"
      },
      fallback: true
    };
  }
  return { mcx: mcx, fallback: false };
}

/* ---- Rate board (v1.3) ----
   User's own purity map: 22K = 92%, 20K = 85%, 18K = 76%, 14K = 60%
   of the MCX gold rate (per 10 g). Silver is the MCX silver rate per kg.
   Prices are whole rupees, jeweller style. */
var BOARD_PURITY = [
  { label: "24K", pct: 100, f: 1.00 },
  { label: "22K", pct: 92, f: 0.92 },
  { label: "20K", pct: 85, f: 0.85 },
  { label: "18K", pct: 76, f: 0.76 },
  { label: "14K", pct: 60, f: 0.60 }
];
function boardRates(goldLast, silverLast, premiums) {
  // v1.4: dikhaya jaane wala rate premium ke BAAD wala hota hai —
  // board aur final price dono me MCX + premium use hota hai.
  var pg = (premiums && premiums.gold) || 0;
  var ps = (premiums && premiums.silver) || 0;
  var gold = (goldLast === null || goldLast === undefined) ? null : goldLast + pg;
  var silver = (silverLast === null || silverLast === undefined) ? null : silverLast + ps;
  var rows = BOARD_PURITY.map(function (r) {
    return {
      label: r.label, pct: r.pct,
      price: gold === null ? null : Math.round(gold * r.f),
      unit: "/10g"
    };
  });
  rows.push({
    label: "Silver", pct: null,
    price: silver === null ? null : Math.round(silver),
    unit: "/kg"
  });
  return rows;
}

/* ---- Quotation URL builder (v1.5) ----
   OMUNIM's Quotation button is an anchor whose onclick does
   window.open('.../ogiaquot.php?<params>', 'popup', 'width=410,height=420,...').
   The URL is baked server-side. The estimate page is a pure GET render
   (verified live 28 Nov 2026, 10-variant matrix on LGB1 + DLR16):
   - metalRate -> Gold Rate line + the "@ rate" on the NT WT line
   - custValuation -> NT WT amount AS-IS (not recomputed)
   - makingCharges / totalOthCharges / valueAdded / hallmarkCharges -> as-is
   - TAXABLE = custValuation + diaAmt(DB lookup) + making + other + valueAdded + hallmark
   - CGST/SGST = totalTax/2 each; TOTAL = TAXABLE + round(totalTax, 2)
   - custFinalValuation, productMRP, quotLay: no visible effect
   - dia comes from the DB item lookup (newItemId + newPreItemId), NOT the URL
   So: read the live onclick URL, substitute only the rate-dependent
   params, keep everything else (incl. newItemId/newPreItemId) untouched.
   Metal basis (user's choice, 28 Nov 2026): OMUNIM's own — NET weight x
   rate — so the receipt's arithmetic stays correct (2.070 GM @ rate =
   custValuation). The panel's FINAL PRICE stays fine-weight based.
   Silver assumption (untested — no silver item checked live): metalRate
   is the per-kg rate, custValuation = netWt x rate/1000. */
function round2(n) { return Math.round(n * 100) / 100; }

function buildQuotationUrl(pageUrl, parsed, calc, effRate) {
  if (!pageUrl || !parsed || !calc || effRate === null || effRate === undefined) return null;
  var u;
  try { u = new URL(pageUrl); } catch (e) { return null; }
  if (u.pathname.indexOf("ogiaquot.php") === -1) return null;
  var isSilver = !!calc.isSilver;
  var ratePerGram = isSilver ? effRate / 1000 : effRate / 10;
  var netWt = parsed.netWt !== null && parsed.netWt !== undefined ? parsed.netWt
    : (parsed.totalWt !== null && parsed.totalWt !== undefined ? parsed.totalWt : parsed.grossWt);
  if (netWt === null || netWt === undefined) return null;
  var netMetal = netWt * ratePerGram;
  // Making against the NEW (net) metal: % scales with metal; GM/PP/Fixed unchanged.
  var makingAmt = calc.making ? calc.making.amount : (parsed.makingAmtOld || 0);
  if (calc.making && calc.making.unit === "%" && calc.making.rate) {
    makingAmt = (netMetal * calc.making.rate) / 100;
  }
  var dia = calc.dia || 0;
  var hallmark = calc.hallmark || 0;
  var other = calc.other || 0;
  var valueAdded = parseFloat(u.searchParams.get("valueAdded")) || 0;
  var taxable = netMetal + dia + makingAmt + hallmark + other + valueAdded;
  var gstRate = calc.gstRate || 0.03;
  var totalTax = round2(taxable * gstRate);
  var finalTotal = round2(taxable + totalTax);
  var p = u.searchParams;
  p.set("metalRate", String(effRate));
  p.set("custValuation", String(round2(netMetal)));
  p.set("makingCharges", String(round2(makingAmt)));
  p.set("totalTax", String(totalTax));
  p.set("custFinalValuation", String(finalTotal));
  return u.toString();
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { parseNum: parseNum, formatINR: formatINR, parseFdFeed: parseFdFeed, parseMcxPage: parseMcxPage, parsePanelText: parsePanelText, computePrice: computePrice, pickRate: pickRate, boardRates: boardRates, buildQuotationUrl: buildQuotationUrl };
}
