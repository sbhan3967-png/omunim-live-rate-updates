/* OMUNIM Live MCX Rate Calculator — content script.
   Runs ONLY on https://release.omunim.in/2/omHomePage.php?divPanel=OwnerHome
   (checked below). Reads the open ITEM DETAILS PANEL by its label
   text, asks the background worker for the live MCX rate from
   mcxlive.org (refreshed every 1 minute), and shows the final price
   after ALL charges. The OMUNIM Metal Amount is never used.
*/
(function () {
  "use strict";
  if (window.__omunimLiveRateInjected) return;
  window.__omunimLiveRateInjected = true;

  // --- Only on the OwnerHome page the user named ---
  var isOwnerHome =
    location.hostname === "release.omunim.in" &&
    location.pathname.indexOf("/2/omHomePage.php") !== -1 &&
    location.search.indexOf("divPanel=OwnerHome") !== -1;
  if (!isOwnerHome) return;

  var state = {
    parsed: null,
    calc: null,
    mcx: null,          // {gold, silver, fetchedAt, source}
    mcxError: null,
    mcxStale: false,
    mcxFallback: false, // true when rate came from OMUNIM's own top bar
    premiums: { gold: 0, silver: 0 },
    enabled: true,
    minimised: false,
    refreshing: false,
    update: null
  };

  /* ---------- floating panel (Shadow DOM, so OMUNIM CSS can't break it) ---------- */
  var host = document.createElement("div");
  host.id = "omunim-live-rate-host";
  host.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:2147483647;font-family:Arial,sans-serif;";
  document.documentElement.appendChild(host);
  var shadow = host.attachShadow({ mode: "open" });

  var css = [
    ".panel{width:360px;max-width:calc(100vw - 24px);max-height:82vh;overflow:auto;background:#fff;border:2px solid #b8860b;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.35);color:#222;font-size:13px}",
    ".head{display:flex;align-items:center;gap:8px;background:linear-gradient(90deg,#8a6d1b,#b8860b);color:#fff;padding:9px 10px;position:sticky;top:0}",
    ".head b{flex:1;font-size:14px}",
    ".dot{width:9px;height:9px;border-radius:50%;background:#37d67a;display:inline-block}",
    ".dot.stale{background:#f5a623}",
    ".dot.off{background:#e5484d}",
    ".hbtn{background:rgba(255,255,255,.22);border:0;color:#fff;border-radius:6px;padding:4px 8px;cursor:pointer;font-size:12px}",
    ".body{padding:10px 12px 12px}",
    ".row{display:flex;justify-content:space-between;gap:10px;padding:3px 0}",
    ".row .k{color:#555}",
    ".row .v{text-align:right;font-variant-numeric:tabular-nums}",
    ".strike{text-decoration:line-through;color:#999}",
    ".final{background:#e8f7ee;border:1.5px solid #1e9e4a;border-radius:8px;padding:8px 10px;margin-top:8px;display:flex;justify-content:space-between;align-items:center}",
    ".final b{font-size:19px;color:#0d7a33}",
    ".diff{font-weight:bold}",
    ".diff.up{color:#c0392b}.diff.down{color:#0d7a33}",
    ".note{font-size:11.5px;color:#666;margin-top:8px;line-height:1.45}",
    ".warn{font-size:11.5px;color:#8a5a00;background:#fff4d6;border-radius:6px;padding:6px 8px;margin-top:8px;line-height:1.45}",
    ".prem{display:flex;gap:8px;margin-top:10px}",
    ".prem label{flex:1;font-size:11.5px;color:#555}",
    ".prem input{width:100%;box-sizing:border-box;padding:6px;border:1px solid #ccc;border-radius:6px;margin-top:3px;font-size:13px}",
    ".prem button{padding:6px 10px;border:0;border-radius:6px;background:#b8860b;color:#fff;cursor:pointer;font-size:12px}",
    ".small{font-size:11.5px;color:#777}",
    "hr{border:0;border-top:1px solid #e5e5e5;margin:8px 0}"
  ].join("\n");

  function esc(s) {
    return String(s === null || s === undefined ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function inr(n, d) { return "\u20b9" + formatINR(n, d === undefined ? 2 : d); }
  function timeStr(iso) {
    if (!iso) return "";
    try {
      var dt = new Date(iso);
      return dt.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: true });
    } catch (e) { return String(iso); }
  }

  function render() {
    if (!state.enabled) { shadow.innerHTML = ""; return; }
    var dotCls = !state.mcx ? "off" : (state.mcxStale || state.mcxFallback ? "stale" : "");
    var dotTitle = !state.mcx ? "Rate nahi mila" : (state.mcxStale ? "Purana rate — refresh ho raha hai" : "Live rate");
    var head = '<div class="head"><span class="dot ' + dotCls + '" title="' + dotTitle + '"></span>' +
      '<b>LIVE MCX RATE — Final Price</b>' +
      '<button class="hbtn" id="lr-refresh" title="Rate abhi refresh karo">&#8635;</button>' +
      '<button class="hbtn" id="lr-min">' + (state.minimised ? "+" : "–") + '</button></div>';
    var body = "";
    if (!state.minimised) {
      body = '<div class="body">' + bodyHtml() + "</div>";
    }
    shadow.innerHTML = "<style>" + css + '</style><div class="panel">' + head + body + "</div>";
    var r = shadow.getElementById("lr-refresh");
    if (r) r.addEventListener("click", function () { refreshRates(true); });
    var mn = shadow.getElementById("lr-min");
    if (mn) mn.addEventListener("click", function () { state.minimised = !state.minimised; render(); });
    bindPremiumInputs();
  }

  function bodyHtml() {
    var h = "";
    // GitHub update banner (v1.1): new version on the channel.
    if (state.update && state.update.available) {
      h += '<div class="warn">Naya version <b>' + esc(state.update.latest) + '</b> available hai' +
        (state.update.notes ? " — " + esc(state.update.notes) : "") +
        (state.update.url ? ' — <a href="' + esc(state.update.url) + '" target="_blank" rel="noopener">ZIP download karo</a>, phir folder me extract karke chrome://extensions me Reload dabao.' : "") + "</div>";
    }
    // Rate line
    if (state.mcx) {
      var g = state.mcx.gold, s = state.mcx.silver;
      var metalLine = state.calc && state.calc.isSilver
        ? "MCX Silver <b>" + inr(s.last, 0) + " /kg</b>"
        : "MCX Gold <b>" + inr(g.last, 0) + " /10g</b>";
      h += '<div class="row"><span class="k">' + metalLine + '</span><span class="v small">' +
        (state.mcxFallback ? "OMUNIM top bar se" : "mcxlive.org") + " • " + timeStr(state.mcx.fetchedAt) + "</span></div>";
      if (g && g.status) h += '<div class="small">Market: ' + esc(g.status) + (g.last_trade ? " • aakhri trade " + esc(g.last_trade) : "") + "</div>";
      if (state.mcxStale) h += '<div class="warn">Rate 1 minute se purana hai — naya rate lene ki koshish ho rahi hai. Purana rate dikhaya ja raha hai, galat rate nahi.</div>';
      if (state.mcxFallback) h += '<div class="warn">mcxlive.org se rate nahi mila, isliye OMUNIM ke upar wale bar ka MCX rate use kiya hai.</div>';
    } else {
      h += '<div class="warn">Live MCX rate abhi nahi mila' + (state.mcxError ? " (" + esc(state.mcxError) + ")" : "") + '. Refresh dabayein ya 1 minute rukiye.</div>';
    }

    if (!state.parsed) {
      h += '<div class="note">Koi item detail khula nahi hai. OMUNIM me koi bhi item (jaise DLR16) kholo — uska live final price yahan aa jayega.</div>';
      h += premiumHtml();
      return h;
    }

    var p = state.parsed, c = state.calc;
    h += "<hr>";
    h += '<div class="row"><span class="k">Item</span><span class="v"><b>' + esc(p.productCode || "-") + "</b>" +
      (p.barcode ? " • Barcode " + esc(p.barcode) : "") + " • " + esc(p.metal || "") + "</span></div>";
    h += '<div class="row"><span class="k">Net Wt / Fine Wt</span><span class="v">' +
      (p.netWt !== null ? p.netWt.toFixed(3) + " g" : "-") + " / " +
      (c.fineShown !== null ? c.fineShown.toFixed(3) + " g" : "-") +
      (p.finalPurity !== null ? " • Purity " + p.finalPurity + "%" : "") + "</span></div>";

    if (!c || c.newMetal === null) {
      h += '<div class="warn">Fine weight ya live rate nahi mila, isliye metal amount calculate nahi ho paya.</div>';
      h += premiumHtml();
      return h;
    }

    h += '<div class="row"><span class="k">Pure rate (MCX' + (c.premium ? " + premium " + inr(c.premium, 0) : "") + ')</span><span class="v">' +
      inr(c.ratePerGram) + " /g</span></div>";
    h += '<div class="row"><span class="k">Metal Amount (naya)</span><span class="v"><b>' + inr(c.newMetal) + "</b> " +
      '<span class="strike small">' + inr(c.oldMetal) + "</span></span></div>";
    h += '<div class="row"><span class="k">Diamond / Stone (dia Amt)</span><span class="v">' + inr(c.dia) + "</span></div>";
    h += '<div class="row"><span class="k">Making Charges</span><span class="v">' + inr(c.making.amount) +
      '<br><span class="small">' + esc(c.making.basis) + "</span></span></div>";
    h += '<div class="row"><span class="k">Hallmark Charges</span><span class="v">' + inr(c.hallmark) + "</span></div>";
    h += '<div class="row"><span class="k">Other Charges</span><span class="v">' + inr(c.other) + "</span></div>";
    h += "<hr>";
    h += '<div class="row"><span class="k">Subtotal</span><span class="v">' + inr(c.subtotal) + "</span></div>";
    h += '<div class="row"><span class="k">GST (' + (c.gstRate * 100).toFixed(2).replace(/\.00$/, "") + '%)</span><span class="v">' + inr(c.gst) + "</span></div>";
    h += '<div class="final"><span><b>FINAL PRICE</b><br><span class="small">live rate se</span></span><b>' + inr(c.finalPrice) + "</b></div>";
    if (c.oldFinal !== null) {
      var d = c.diff;
      h += '<div class="row" style="margin-top:6px"><span class="k">OMUNIM Price</span><span class="v">' + inr(c.oldFinal) + "</span></div>";
      h += '<div class="row"><span class="k">Fark (Live − OMUNIM)</span><span class="v diff ' + (d < 0 ? "down" : d > 0 ? "up" : "") + '">' +
        (d > 0 ? "+" : "") + inr(d) + "</span></div>";
    }
    h += '<div class="note">OMUNIM ka purana Metal Amount use <b>nahi</b> kiya — metal value fresh MCX rate se banayi hai. Baaki saare charges (diamond, making, hallmark, other) aur GST page par likhe hisaab se liye hain.</div>';
    h += premiumHtml();
    return h;
  }

  function premiumHtml() {
    var g = state.premiums.gold || 0, s = state.premiums.silver || 0;
    return '<div class="prem">' +
      '<label>Gold premium (₹/10g)<input id="lr-premg" type="number" min="0" step="1" value="' + g + '"></label>' +
      '<label>Silver premium (₹/kg)<input id="lr-prems" type="number" min="0" step="1" value="' + s + '"></label>' +
      '<button id="lr-premsave" type="button">Save</button></div>' +
      '<div class="small">Premium baad me kabhi bhi add kar sakte hain — 0 rakha to raw MCX rate use hoga. Rate har 1 minute me apne aap refresh hota hai.</div>';
  }

  function bindPremiumInputs() {
    var btn = shadow.getElementById("lr-premsave");
    if (!btn) return;
    btn.addEventListener("click", function () {
      var g = shadow.getElementById("lr-premg");
      var s = shadow.getElementById("lr-prems");
      state.premiums.gold = Math.max(0, parseFloat(g.value) || 0);
      state.premiums.silver = Math.max(0, parseFloat(s.value) || 0);
      chrome.storage.local.set({ goldPremium: state.premiums.gold, silverPremium: state.premiums.silver }, function () {
        recompute();
      });
    });
  }

  /* ---------- data ---------- */

  function recompute() {
    if (state.parsed) {
      // Fallback: mcxlive fail ho to OMUNIM top bar ka MCX rate use karo.
      if (!state.mcx && state.parsed.topMcxGold) {
        state.mcx = {
          gold: { last: state.parsed.topMcxGold, status: "", last_trade: "" },
          silver: { last: state.parsed.topMcxSilver || 0, status: "", last_trade: "" },
          fetchedAt: new Date().toISOString(), source: "omunim-topbar"
        };
        state.mcxFallback = true;
      }
      state.calc = computePrice(state.parsed, state.mcx, state.premiums);
    } else {
      state.calc = null;
    }
    render();
  }

  function refreshRates(force) {
    if (state.refreshing && !force) return;
    state.refreshing = true;
    var type = force ? "REFRESH_MCX" : "GET_MCX";
    try {
      chrome.runtime.sendMessage({ type: type }, function (res) {
        state.refreshing = false;
        if (!res) { recompute(); return; }
        if (res.mcx) {
          state.mcx = res.mcx;
          state.mcxFallback = false;
          var age = res.mcx.fetchedAt ? Date.now() - new Date(res.mcx.fetchedAt).getTime() : Infinity;
          state.mcxStale = age > 75 * 1000;
        }
        state.mcxError = res.error || null;
        recompute();
      });
    } catch (e) {
      state.refreshing = false;
      recompute();
    }
  }

  var scanTimer = null;
  function scan() {
    var text = "";
    try { text = document.body ? document.body.innerText || "" : ""; } catch (e) { text = ""; }
    var parsed = parsePanelText(text);
    var changed = JSON.stringify(parsed) !== JSON.stringify(state.parsed);
    state.parsed = parsed;
    if (changed || !state.calc) recompute();
  }
  function scheduleScan() {
    if (scanTimer) clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 400);
  }

  /* ---------- boot ---------- */
  chrome.storage.local.get(["goldPremium", "silverPremium", "liveRateEnabled", "update"], function (res) {
    state.premiums.gold = parseFloat(res.goldPremium) || 0;
    state.premiums.silver = parseFloat(res.silverPremium) || 0;
    state.enabled = res.liveRateEnabled !== false;
    state.update = res.update || null;
    render();
    scan();
    refreshRates(false);
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== "local") return;
    if (changes.goldPremium) state.premiums.gold = parseFloat(changes.goldPremium.newValue) || 0;
    if (changes.silverPremium) state.premiums.silver = parseFloat(changes.silverPremium.newValue) || 0;
    if (changes.liveRateEnabled) state.enabled = changes.liveRateEnabled.newValue !== false;
    if (changes.update) state.update = changes.update.newValue || null;
    if (changes.mcx && changes.mcx.newValue) {
      state.mcx = changes.mcx.newValue;
      state.mcxFallback = false;
      state.mcxStale = false;
    }
    recompute();
  });

  // OMUNIM panel AJAX se badalta hai — URL nahi badalta, isliye DOM observe karo.
  var observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // User ka rule: rate har 1 minute me refresh.
  setInterval(function () { refreshRates(true); }, 60 * 1000);
  // Panel scan bhi har 5 second me (koi change miss na ho).
  setInterval(scan, 5000);
})();
