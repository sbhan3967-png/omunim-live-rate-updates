/* OMUNIM Live MCX Rate Calculator — background service worker.
   Fetches live MCX gold + silver from mcxlive.org every 1 minute
   (user's ask: "take rate from https://mcxlive.org/ this and delay
   of 1 min") and caches the last good rate. If a fetch fails, the
   last good rate is kept and marked stale — never a wrong number.
   The content script cannot fetch mcxlive.org directly (CORS), so
   all fetching happens here; the page asks this worker for rates.
*/
importScripts("omunim-parse.js");

var GOLD_URL = "https://mcxlive.org/gold/";
var SILVER_URL = "https://mcxlive.org/silver/";
var REFRESH_MS = 60 * 1000;

/* ---- GitHub auto-update check (v1.1) ----
   Unpacked Chrome extensions cannot self-update the way a Store
   extension does, so this worker checks the public GitHub channel
   (sbhan3967-png/omunim-live-rate-updates, version.json) once an
   hour and whenever the popup asks. If a newer version exists it
   stores {available, latest, url, notes}; the popup and the OMUNIM
   panel show a "Naya version available — Download" banner. The user
   then downloads the new zip, extracts it over the extension folder
   and presses Reload in chrome://extensions. Premium settings live
   in chrome.storage, so they survive the update. */
var UPDATE_CHECK_URLS = [
  "https://raw.githubusercontent.com/sbhan3967-png/omunim-live-rate-updates/main/version.json",
  "https://github.com/sbhan3967-png/omunim-live-rate-updates/raw/main/version.json",
  "https://cdn.jsdelivr.net/gh/sbhan3967-png/omunim-live-rate-updates@main/version.json"
];

function verTuple(v) {
  return String(v || "").split(".").map(function (x) {
    var d = parseInt(String(x).replace(/\D/g, ""), 10);
    return isNaN(d) ? 0 : d;
  });
}
function verNewer(a, b) {
  var ta = verTuple(a), tb = verTuple(b);
  for (var i = 0; i < Math.max(ta.length, tb.length); i++) {
    var x = ta[i] || 0, y = tb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}
function checkForUpdate() {
  var current = chrome.runtime.getManifest().version;
  var best = null;
  var chain = Promise.resolve();
  UPDATE_CHECK_URLS.forEach(function (u) {
    chain = chain.then(function () {
      return fetch(u, { cache: "no-store" }).then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      }).then(function (info) {
        if (info && info.version && (!best || verNewer(info.version, best.version))) best = info;
      }).catch(function () {});
    });
  });
  return chain.then(function () {
    var upd = { available: false, latest: current, url: null, notes: "", checkedAt: new Date().toISOString() };
    if (best && verNewer(best.version, current)) {
      upd.available = true;
      upd.latest = String(best.version);
      upd.url = best.url || null;
      upd.notes = best.notes || "";
    } else if (best) {
      upd.latest = String(best.version);
    }
    return chrome.storage.local.set({ update: upd }).then(function () { return upd; });
  });
}

function fetchPage(url, timeoutMs) {
  var ctrl = new AbortController();
  var t = setTimeout(function () { ctrl.abort(); }, timeoutMs || 15000);
  return fetch(url, {
    signal: ctrl.signal,
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
      "Accept": "text/html,application/xhtml+xml",
      "Accept-Language": "en-IN,en;q=0.9"
    }
  }).then(function (r) {
    clearTimeout(t);
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.text();
  }).catch(function (e) { clearTimeout(t); throw e; });
}

function fetchMcx() {
  return Promise.all([fetchPage(GOLD_URL), fetchPage(SILVER_URL)])
    .then(function (pages) {
      var gold = parseMcxPage(pages[0], "GOLD");
      var silver = parseMcxPage(pages[1], "SILVER");
      if (!gold || !silver) throw new Error("MCX page layout changed — could not parse");
      var data = {
        gold: gold,
        silver: silver,
        fetchedAt: new Date().toISOString(),
        source: "mcxlive.org"
      };
      return chrome.storage.local.set({ mcx: data, mcxError: null }).then(function () { return data; });
    })
    .catch(function (err) {
      // Keep the last good rate; record the failure for the panel.
      return chrome.storage.local.set({ mcxError: String(err && err.message || err), mcxErrorAt: new Date().toISOString() })
        .then(function () { return chrome.storage.local.get(["mcx"]); })
        .then(function (res) { return res.mcx || null; });
    });
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.alarms.create("mcx-refresh", { periodInMinutes: 1 });
  chrome.alarms.create("update-check", { periodInMinutes: 60 });
  fetchMcx();
  checkForUpdate();
});
chrome.runtime.onStartup.addListener(function () {
  chrome.alarms.create("mcx-refresh", { periodInMinutes: 1 });
  chrome.alarms.create("update-check", { periodInMinutes: 60 });
  fetchMcx();
  checkForUpdate();
});
chrome.alarms.onAlarm.addListener(function (alarm) {
  if (!alarm) return;
  if (alarm.name === "mcx-refresh") fetchMcx();
  if (alarm.name === "update-check") checkForUpdate();
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return false;
  if (msg.type === "GET_MCX") {
    chrome.storage.local.get(["mcx", "mcxError", "mcxErrorAt"]).then(function (res) {
      sendResponse({ mcx: res.mcx || null, error: res.mcxError || null, errorAt: res.mcxErrorAt || null });
      // Refresh in the background if the cached rate is over 1 minute old.
      var age = res.mcx && res.mcx.fetchedAt ? Date.now() - new Date(res.mcx.fetchedAt).getTime() : Infinity;
      if (age > REFRESH_MS) fetchMcx();
    });
    return true;
  }
  if (msg.type === "REFRESH_MCX") {
    fetchMcx().then(function (data) {
      chrome.storage.local.get(["mcxError"]).then(function (res) {
        sendResponse({ mcx: data, error: res.mcxError || null });
      });
    });
    return true;
  }
  if (msg.type === "CHECK_UPDATE") {
    checkForUpdate().then(function (upd) { sendResponse({ update: upd }); });
    return true;
  }
  return false;
});
