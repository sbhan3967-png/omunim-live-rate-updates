/* Node test for OMUNIM Live MCX Rate Calculator.
   Run: node test/test_calc.js
   Checks the FD_FEED parser and the price maths against the VERIFIED
   DLR16 values from the live OMUNIM panel (22 Nov 2026). */
"use strict";
const assert = require("assert");
const lib = require("../omunim-parse.js");

// --- 1. FD_FEED parser (real sample shape from Weighing Scale TEST 19) ---
const sampleGold =
  '<html><script>window.FD_FEED={"id":"750","symbol":"Gold","name":"MCX Gold","expiry":"2026-12-04","last":131054,"close":134223,"high":131979,"low":130821,"open":131622,"c_value":-3169,"c_percent":-2.361,"status":"Open","t_datetime":"2026-11-18 10:43:00","c_datetime":"2026-11-18 10:44:05"};window.FD_DATA={"name":"MCX Gold"}</script></html>';
const g = lib.parseMcxPage(sampleGold, "GOLD");
assert.strictEqual(g.last, 131054, "FD_FEED gold last");
assert.strictEqual(g.unit, "10 g");
assert.strictEqual(g.contract, "2026-12-04");
assert.strictEqual(lib.parseMcxPage("<html>no feed here</html>", "GOLD"), null, "no-feed page -> null");

// --- 2. Panel parsing on the verified DLR16 text (exact labels) ---
const panelText = [
  "ITEM DETAILS PANEL",
  "Dlring",
  "Product Code : DLR16   Barcode No : 1016   Metal : Gold   Firm : AD",
  "Item Quantity : 1",
  "Gross Weight : 4.730 GM",
  "Less Weight : 0.000 GM",
  "Pkt Weight : 0.000 GM",
  "Net Weight : 4.512 GM",
  "V/A Wt (0%) : 0.000 GM",
  "Total Weight : 4.512 GM",
  "Purity : 60.000 %",
  "Item Wastage : 0.00 %",
  "Final Purity : 60.00 %",
  "Fine Weight : 2.707 GM",
  "Other Charges : 1000 Fixed",
  "Final Fine Weight : 2.707 GM",
  "Metal Amount : 34,977.02",
  "dia Amt : 43,600.00",
  "Making Charges (1200 GM) : 3,248.64",
  "Hallmark Charges : 200.00",
  "Other Charges : 1,000.00",
  "Total Amount : 83,025.66",
  "GST Amount : 2,490.77",
  "Price : \u20b9 85,516.43",
  "Final Price \u20b9 85,516.43",
  "MCX Gold:121949",
  "MCX Silver:148900",
  "SR.NO. DETAILS COLOR CLARITY QTY GS WT AMT",
  "1 dia SI FG 1 1.090 CT 43600"
].join("\n");
const p = lib.parsePanelText(panelText);
assert.ok(p, "panel parsed");
assert.strictEqual(p.productCode, "DLR16");
assert.strictEqual(p.barcode, "1016");
assert.strictEqual(p.metal, "Gold");
assert.strictEqual(p.netWt, 4.512);
assert.strictEqual(p.finalPurity, 60);
assert.strictEqual(p.fineWt, 2.707);
assert.strictEqual(p.metalAmtOld, 34977.02);
assert.strictEqual(p.diaAmt, 43600);
assert.strictEqual(p.makingBracket, "1200 GM");
assert.strictEqual(p.makingAmtOld, 3248.64);
assert.strictEqual(p.hallmarkAmt, 200);
assert.strictEqual(p.otherAmt, 1000);
assert.strictEqual(p.totalAmtOld, 83025.66);
assert.strictEqual(p.gstAmtOld, 2490.77);
assert.strictEqual(p.finalPriceOld, 85516.43);
assert.strictEqual(p.topMcxGold, 121949);

// --- 3. Price maths, live MCX gold 121949, no premium ---
const rates = { gold: { last: 121949 }, silver: { last: 148900 } };
const c = lib.computePrice(p, rates, { gold: 0, silver: 0 });
const close = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.02, msg + ": got " + a + ", want " + b);
close(c.fineExact, 2.7072, "fineExact = net x final purity (unrounded)");
close(c.newMetal, 33014.03, "new metal");
close(c.making.amount, 3248.64, "making 1200 x fine");
assert.strictEqual(c.making.basis.indexOf("fine wt") !== -1, true, "making base = fine wt");
close(c.subtotal, 81062.67, "subtotal");
close(c.gstRate, 0.03, "gst rate from page");
close(c.gst, 2431.88, "gst");
close(c.finalPrice, 83494.55, "final price");
close(c.diff, -2021.88, "diff vs OMUNIM price");
// OMUNIM's own old metal must NOT be used: with old rate the answer differs.
assert.ok(Math.abs(c.newMetal - p.metalAmtOld) > 1000, "new metal differs from stale OMUNIM metal");

// --- 4. Premium: +1000/10g gold -> metal +270.72, final +278.84 ---
const cp = lib.computePrice(p, rates, { gold: 1000, silver: 0 });
close(cp.newMetal, 33014.03 + 270.72, "premium metal");
close(cp.finalPrice, 83494.55 + 270.72 * 1.03, "premium final");

// --- 5. Making as % of metal ---
const ppct = Object.assign({}, p, { makingBracket: "10 %", makingAmtOld: 3497.70 });
const cpct = lib.computePrice(ppct, rates, { gold: 0, silver: 0 });
close(cpct.making.amount, 3301.40, "making 10% of new metal");

// --- 6. Making per piece ---
const ppp = Object.assign({}, p, { makingBracket: "500 PP", makingAmtOld: 500, qty: 1 });
close(lib.computePrice(ppp, rates, { gold: 0, silver: 0 }).making.amount, 500, "making per piece");

// --- 7. Silver item: fine 100 g, silver 148900/kg -> metal 14,890 ---
const ps = { metal: "Silver", netWt: 100, finalPurity: 100, fineWt: 100, finalFineWt: 100, purity: 100, wastage: 0, qty: 1, diaAmt: 0, makingAmtOld: 0, makingBracket: null, hallmarkAmt: 0, otherAmt: 0, totalAmtOld: 10000, gstAmtOld: 300, metalAmtOld: 0, priceOld: null, finalPriceOld: null };
const cs = lib.computePrice(ps, rates, { gold: 0, silver: 0 });
close(cs.newMetal, 14890, "silver metal");
close(cs.finalPrice, 14890 * 1.03, "silver final");

console.log("ALL TESTS PASS");
console.log("DLR16 live final: \u20b9" + lib.formatINR(c.finalPrice) + " (OMUNIM \u20b9" + lib.formatINR(c.oldFinal) + ", diff \u20b9" + lib.formatINR(c.diff) + ")");
