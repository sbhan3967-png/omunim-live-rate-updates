/* OMUNIM Live MCX Rate Calculator — content script.
   Runs ONLY on https://release.omunim.in/2/omHomePage.php?divPanel=OwnerHome
   (checked below). Reads the open ITEM DETAILS PANEL by its label
   text, asks the background worker for the live MCX rate from
   mcxlive.org (refreshed every 1 minute), and shows the final price
   after ALL charges. The OMUNIM Metal Amount is never used.
*/
(function () {
  "use strict";
  if (window.__omunimLiveRateInjected) return;
  window.__omunimLiveRateInjected = true;

  // --- Only on the OwnerHome page the user named ---
  var isOwnerHome =
    location.hostname === "release.omunim.in" &&
    location.pathname.indexOf("/2/omHomePage.php") !== -1 &&
    location.search.indexOf("divPanel=OwnerHome") !== -1;
  if (!isOwnerHome) return;

  var state = {
    parsed: null,
    calc: null,
    mcx: null,          // {gold, silver, fetchedAt, source}
    mcxError: null,
    mcxStale: false,
    mcxFallback: false, // true when rate came from OMUNIM's own top bar
    premiums: { gold: 0, silver: 0 },
    enabled: true,
    minimised: false,
    refreshing: false,
    nextRefreshAt: 0,
    update: null
  };

  /* ---------- floating panel (Shadow DOM, so OMUNIM CSS can't break it) ---------- */
  var host = document.createElement("div");
  host.id = "omunim-live-rate-host";
  host.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:2147483647;font-family:Arial,sans-serif;";
  document.documentElement.appendChild(host);
  var shadow = host.attachShadow({ mode: "open" });

  var css = [
    ".panel{width:360px;max-width:calc(100vw - 24px);max-height:82vh;overflow:auto;background:#fff;border:2px solid #b8860b;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.35);color:#222;font-size:13px}",
    ".head{display:flex;align-items:center;gap:8px;background:linear-gradient(90deg,#8a6d1b,#b8860b);color:#fff;padding:9px 10px;position:sticky;top:0}",
    ".head b{flex:1;font-size:14px}",
    ".dot{width:9px;height:9px;border-radius:50%;background:#37d67a;display:inline-block}",
    ".dot.stale{background:#f5a623}",
    ".dot.off{background:#e5484d}",
    ".hbtn{background:rgba(255,255,255,.22);border:0;color:#fff;border-radius:6px;padding:4px 8px;cursor:pointer;font-size:12px}",
    ".body{padding:10px 12px 12px}",
    ".row{display:flex;justify-content:space-between;gap:10px;padding:3px 0}",
    ".row .k{color:#555}",
    ".row .v{text-align:right;font-variant-numeric:tabular-nums}",
    ".strike{text-decoration:line-through;color:#999}",
    ".final{background:#e8f7ee;border:1.5px solid #1e9e4a;border-radius:8px;padding:8px 10px;margin-top:8px;display:flex;justify-content:space-between;align-items:center}",
    ".final b{font-size:19px;color:#0d7a33}",
    ".diff{font-weight:bold}",
    ".diff.up{color:#c0392b}.diff.down{color:#0d7a33}",
    ".note{font-size:11.5px;color:#666;margin-top:8px;line-height:1.45}",
    ".warn{font-size:11.5px;color:#8a5a00;background:#fff4d6;border-radius:6px;padding:6px 8px;margin-top:8px;line-height:1.45}",
    ".prem{display:flex;gap:8px;margin-top:10px}",
    ".prem label{flex:1;font-size:11.5px;color:#555}",
    ".prem input{width:100%;box-sizing:border-box;padding:6px;border:1px solid #ccc;border-radius:6px;margin-top:3px;font-size:13px}",
    ".prem button{padding:6px 10px;border:0;border-radius:6px;background:#b8860b;color:#fff;cursor:pointer;font-size:12px}",
    ".small{font-size:11.5px;color:#777}",
    "hr{border:0;border-top:1px solid #e5e5e5;margin:8px 0}"
  ].join("\n");

  function esc(s) {
    return String(s === null || s === undefined ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function inr(n, d) { return "\u20b9" + formatINR(n, d === undefined ? 2 : d); }
  function timeStr(iso) {
    if (!iso) return "";
    try {
      var dt = new Date(iso);
      return dt.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: true });
    } catch (e) { return String(iso); }
  }

  function render() {
    if (!state.enabled) { shadow.innerHTML = ""; return; }
    var dotCls = !state.mcx ? "off" : (state.mcxStale || state.mcxFallback ? "stale" : "");
    var dotTitle = !state.mcx ? "Rate nahi mila" : (state.mcxStale ? "Purana rate — refresh ho raha hai" : "Live rate");
    var head = '<div class="head"><span class="dot ' + dotCls + '" title="' + dotTitle + '"></span>' +
      '<span style="flex:1"></span>' +
      '<button class="hbtn" id="lr-refresh" title="Rate abhi refresh karo">&#8635;</button>' +
      '<button class="hbtn" id="lr-min">' + (state.minimised ? "+" : "–") + '</button></div>';
    var body = "";
    if (!state.minimised) {
      body = '<div class="body">' + bodyHtml() + "</div>";
    }
    shadow.innerHTML = "<style>" + css + '</style><div class="panel">' + head + body + "</div>";
    var r = shadow.getElementById("lr-refresh");
    if (r) r.addEventListener("click", function () { refreshRates(true); });
    var mn = shadow.getElementById("lr-min");
    if (mn) mn.addEventListener("click", function () { state.minimised = !state.minimised; render(); });
    // v1.3 fix: clock nodes ko turant bharo — render shadow DOM dobara
    // banata hai, aur 1s tick ka intezar karne par (khaas taur par
    // fallback mode me, jahan har scan render karta hai) ghadi "—" dikhti.
    tickClock();
  }

  // v1.3 minimal panel: no item open -> sirf rate board (6 rows + time).
  // Item open -> sirf Item + MCX rate + bada FINAL PRICE + OMUNIM/fark.
  // Breakdown, note aur premium inputs panel se hata diye (premium
  // popup me set hota hai).
  function boardHtml() {
    var h = "";
    var rows = boardRates(state.mcx ? state.mcx.gold.last : null, state.mcx ? state.mcx.silver.last : null, state.premiums);
    rows.forEach(function (r) {
      h += '<div class="row"><span class="k" style="font-size:14px">' + esc(r.label) +
        (r.pct !== null && r.pct !== 100 ? ' <span class="small">' + r.pct + '%</span>' : "") +
        '</span><span class="v" style="font-size:16px;font-weight:bold">' +
        (r.price === null ? "—" : inr(r.price, 0)) + ' <span class="small">' + r.unit + "</span></span></div>";
    });
    h += '<div style="text-align:right;margin-top:4px" class="small"><span id="lr-clock">—</span></div>';
    return h;
  }

  function bodyHtml() {
    var h = "";
    // GitHub update banner (v1.1): new version on the channel.
    if (state.update && state.update.available) {
      h += '<div class="warn">Naya version <b>' + esc(state.update.latest) + '</b> available hai' +
        (state.update.notes ? " — " + esc(state.update.notes) : "") +
        (state.update.url ? ' — <a href="' + esc(state.update.url) + '" target="_blank" rel="noopener">ZIP download karo</a>, phir folder me extract karke chrome://extensions me Reload dabao.' : "") + "</div>";
    }
    if (!state.parsed) return h + boardHtml();
    // Item row pehle, phir minimal rate line (sirf rate + source + clock).
    var p = state.parsed, c = state.calc;
    h += '<div class="row"><span class="k">Item</span><span class="v"><b>' + esc(p.productCode || "-") + "</b>" +
      (p.barcode ? " • " + esc(p.barcode) : "") + " • " + esc(p.metal || "") + "</span></div>";
    if (!state.mcx) {
      h += '<div class="warn">Live MCX rate abhi nahi mila' + (state.mcxError ? " (" + esc(state.mcxError) + ")" : "") + '. Refresh dabayein ya 1 minute rukiye.</div>';
      return h;
    }
    var g = state.mcx.gold, s = state.mcx.silver;
    // v1.4: dikhaya jaane wala rate premium ke baad wala hai (wahi rate
    // jo FINAL PRICE me use hota hai).
    var effGold = g.last + (state.premiums.gold || 0);
    var effSilver = s.last + (state.premiums.silver || 0);
    var metalLine = c && c.isSilver
      ? "MCX Silver <b>" + inr(effSilver, 0) + " /kg</b>"
      : "MCX Gold <b>" + inr(effGold, 0) + " /10g</b>";
    h += '<div class="row"><span class="k">' + metalLine + '</span><span class="v small">' +
      (state.mcxFallback ? "OMUNIM top bar se" : "mcxlive.org") + "</span></div>";
    h += '<div class="row"><span class="k small" id="lr-clock">—</span><span class="v small" id="lr-next"></span></div>';
    if (state.mcxStale && !state.mcxFallback) h += '<div class="warn">Purana rate — refresh ho raha hai.' + (state.mcxError ? " " + esc(state.mcxError) : "") + "</div>";

    if (!c || c.newMetal === null) {
      h += '<div class="warn">Final price calculate nahi ho paya.</div>';
      return h;
    }
    h += '<div class="final"><span><b>FINAL PRICE</b></span><b>' + inr(c.finalPrice) + "</b></div>";
    if (c.oldFinal !== null) {
      var d = c.diff;
      h += '<div class="row" style="margin-top:6px"><span class="k">OMUNIM ' + inr(c.oldFinal) + '</span><span class="v diff ' + (d < 0 ? "down" : d > 0 ? "up" : "") + '">Fark ' + (d > 0 ? "+" : "") + inr(d) + "</span></div>";
    }
    return h;
  }

  // v1.3: premium inputs panel se hata diye — premium popup (toolbar icon)
  // se set hota hai, wahi chrome.storage me save hota hai.

  /* ---------- v1.5: Quotation button interception ----------
     OMUNIM's Quotation anchor opens ogiaquot.php via an inline onclick
     window.open(url, 'popup', ...). A capture-phase listener catches the
     click before the inline handler runs; if we have a live rate + an
     open item, open the SAME page with MCX+premium values instead.
     If anything is missing, let OMUNIM's own click go through untouched.
     (window.open from the content script opens a new tab with the same
     estimate page, instead of OMUNIM's small 410x420 popup window.) */
  function quotationOnClick(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[onclick*="ogiaquot.php"]') : null;
    if (!a) return;
    if (!state.parsed || !state.calc || !state.mcx) return;
    var eff = state.calc.mcxWithPremium;
    if (eff === null || eff === undefined) return;
    var onc = a.getAttribute("onclick") || "";
    var um = onc.match(/window\.open\('([^']+)'/);
    if (!um) return;
    var newUrl = buildQuotationUrl(um[1], state.parsed, state.calc, eff);
    if (!newUrl) return;
    e.preventDefault();
    e.stopPropagation();
    window.open(newUrl, "popup", "width=410,height=420,scrollbars=yes,resizable=yes,toolbar=no,directories=no,location=no,menubar=no,status=no,left=0,top=0");
  }
  document.addEventListener("click", quotationOnClick, true);

  /* ---------- data ---------- */

  function recompute() {
    if (state.parsed) {
      // v1.2: rate pick karo — fresh mcxlive rate ho to wahi, warna
      // (90 second se purana ho to) OMUNIM top bar ka MCX rate.
      var picked = pickRate(state.mcx, state.parsed, Date.now());
      state.mcx = picked.mcx;
      state.mcxFallback = picked.fallback;
      state.calc = computePrice(state.parsed, state.mcx, state.premiums);
    } else {
      state.calc = null;
    }
    render();
  }

  function refreshRates(force) {
    if (state.refreshing && !force) return;
    state.refreshing = true;
    state.nextRefreshAt = Date.now() + 60 * 1000;
    var type = force ? "REFRESH_MCX" : "GET_MCX";
    try {
      chrome.runtime.sendMessage({ type: type }, function (res) {
        state.refreshing = false;
        if (!res) { recompute(); return; }
        if (res.mcx) {
          state.mcx = res.mcx;
          state.mcxFallback = false;
          var age = res.mcx.fetchedAt ? Date.now() - new Date(res.mcx.fetchedAt).getTime() : Infinity;
          state.mcxStale = age > 75 * 1000 || res.mcx.goldFresh === false;
        }
        state.mcxError = res.error || null;
        recompute();
      });
    } catch (e) {
      state.refreshing = false;
      recompute();
    }
  }

  var scanTimer = null;
  function scan() {
    var text = "";
    try { text = document.body ? document.body.innerText || "" : ""; } catch (e) { text = ""; }
    var parsed = parsePanelText(text);
    var changed = JSON.stringify(parsed) !== JSON.stringify(state.parsed);
    state.parsed = parsed;
    // Fallback rate top bar se aata hai to har scan par dobara pick karo,
    // taaki top bar ka naya rate bhi turant price me aa jaye.
    if (changed || !state.calc || state.mcxFallback) recompute();
  }
  function scheduleScan() {
    if (scanTimer) clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 400);
  }

  /* ---------- boot ---------- */
  chrome.storage.local.get(["goldPremium", "silverPremium", "liveRateEnabled", "update"], function (res) {
    state.premiums.gold = parseFloat(res.goldPremium) || 0;
    state.premiums.silver = parseFloat(res.silverPremium) || 0;
    state.enabled = res.liveRateEnabled !== false;
    state.update = res.update || null;
    render();
    scan();
    refreshRates(false);
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== "local") return;
    if (changes.goldPremium) state.premiums.gold = parseFloat(changes.goldPremium.newValue) || 0;
    if (changes.silverPremium) state.premiums.silver = parseFloat(changes.silverPremium.newValue) || 0;
    if (changes.liveRateEnabled) state.enabled = changes.liveRateEnabled.newValue !== false;
    if (changes.update) state.update = changes.update.newValue || null;
    if (changes.mcx && changes.mcx.newValue) {
      state.mcx = changes.mcx.newValue;
      state.mcxFallback = false;
      // v1.3: stale merge (fetch fail) bhi naya object hota hai — uski
      // fetchedAt/fresh flags se staleness nikalo, blindly fresh mat mano.
      var age = changes.mcx.newValue.fetchedAt ? Date.now() - new Date(changes.mcx.newValue.fetchedAt).getTime() : Infinity;
      state.mcxStale = age > 75 * 1000 || changes.mcx.newValue.goldFresh === false;
    }
    recompute();
  });

  // OMUNIM panel AJAX se badalta hai — URL nahi badalta, isliye DOM observe karo.
  var observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // v1.2: ticking clock — har second "Updated HH:MM:SS" aur
  // "Next refresh in Ns" update karo, taaki refresh dikhai de.
  // Sirf clock wale nodes ka text badalta hai (poora panel dobara
  // render nahi hota, warna premium type karte waqt focus chala jata).
  function tickClock() {
    var c = shadow.getElementById("lr-clock");
    var n = shadow.getElementById("lr-next");
    if (!c && !n) return;
    if (c) {
      var t = state.mcx && state.mcx.fetchedAt ? new Date(state.mcx.fetchedAt) : null;
      c.textContent = t ? t.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true }) : "—";
    }
    if (n) {
      if (state.refreshing) n.textContent = "Refreshing…";
      else if (state.nextRefreshAt) {
        var s = Math.max(0, Math.ceil((state.nextRefreshAt - Date.now()) / 1000));
        n.textContent = "Next refresh in " + s + "s";
      } else n.textContent = "";
    }
  }
  setInterval(tickClock, 1000);

  // User ka rule: rate har 1 minute me refresh.
  setInterval(function () { refreshRates(true); }, 60 * 1000);
  // Panel scan bhi har 5 second me (koi change miss na ho).
  setInterval(scan, 5000);
})();
